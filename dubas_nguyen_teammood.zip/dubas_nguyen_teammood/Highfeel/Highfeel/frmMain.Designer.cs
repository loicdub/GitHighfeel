﻿namespace Highfeel
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbClan = new System.Windows.Forms.ListBox();
            this.btnCreateClan = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pbxGrade1 = new System.Windows.Forms.PictureBox();
            this.lblAverageGrade = new System.Windows.Forms.Label();
            this.pbxGrade6 = new System.Windows.Forms.PictureBox();
            this.pbxGrade2 = new System.Windows.Forms.PictureBox();
            this.pbxGrade8 = new System.Windows.Forms.PictureBox();
            this.pbxGrade4 = new System.Windows.Forms.PictureBox();
            this.pbxGrade3 = new System.Windows.Forms.PictureBox();
            this.pbxGrade5 = new System.Windows.Forms.PictureBox();
            this.pbxGrade7 = new System.Windows.Forms.PictureBox();
            this.pbxGrade10 = new System.Windows.Forms.PictureBox();
            this.pbxGrade9 = new System.Windows.Forms.PictureBox();
            this.tbxMembers = new System.Windows.Forms.TextBox();
            this.lblConnectedUser = new System.Windows.Forms.Label();
            this.btnAddMember = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade9)).BeginInit();
            this.SuspendLayout();
            // 
            // lbClan
            // 
            this.lbClan.FormattingEnabled = true;
            this.lbClan.Location = new System.Drawing.Point(12, 12);
            this.lbClan.Name = "lbClan";
            this.lbClan.Size = new System.Drawing.Size(140, 303);
            this.lbClan.TabIndex = 1;
            this.lbClan.SelectedIndexChanged += new System.EventHandler(this.lbClan_SelectedIndexChanged);
            // 
            // btnCreateClan
            // 
            this.btnCreateClan.Location = new System.Drawing.Point(12, 321);
            this.btnCreateClan.Name = "btnCreateClan";
            this.btnCreateClan.Size = new System.Drawing.Size(140, 40);
            this.btnCreateClan.TabIndex = 0;
            this.btnCreateClan.Text = "Créer un clan";
            this.btnCreateClan.UseVisualStyleBackColor = true;
            this.btnCreateClan.Click += new System.EventHandler(this.btnCreateClan_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(364, 12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(186, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // pbxGrade1
            // 
            this.pbxGrade1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade1.Location = new System.Drawing.Point(364, 38);
            this.pbxGrade1.Name = "pbxGrade1";
            this.pbxGrade1.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade1.TabIndex = 4;
            this.pbxGrade1.TabStop = false;
            this.pbxGrade1.Tag = "1";
            this.pbxGrade1.Click += new System.EventHandler(this.pbx_Click);
            // 
            // lblAverageGrade
            // 
            this.lblAverageGrade.AutoSize = true;
            this.lblAverageGrade.Location = new System.Drawing.Point(158, 321);
            this.lblAverageGrade.Name = "lblAverageGrade";
            this.lblAverageGrade.Size = new System.Drawing.Size(75, 13);
            this.lblAverageGrade.TabIndex = 5;
            this.lblAverageGrade.Text = "Moyenne de : ";
            // 
            // pbxGrade6
            // 
            this.pbxGrade6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade6.Location = new System.Drawing.Point(492, 102);
            this.pbxGrade6.Name = "pbxGrade6";
            this.pbxGrade6.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade6.TabIndex = 10;
            this.pbxGrade6.TabStop = false;
            this.pbxGrade6.Tag = "6";
            this.pbxGrade6.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade2
            // 
            this.pbxGrade2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade2.Location = new System.Drawing.Point(428, 38);
            this.pbxGrade2.Name = "pbxGrade2";
            this.pbxGrade2.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade2.TabIndex = 11;
            this.pbxGrade2.TabStop = false;
            this.pbxGrade2.Tag = "2";
            this.pbxGrade2.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade8
            // 
            this.pbxGrade8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade8.Location = new System.Drawing.Point(428, 166);
            this.pbxGrade8.Name = "pbxGrade8";
            this.pbxGrade8.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade8.TabIndex = 12;
            this.pbxGrade8.TabStop = false;
            this.pbxGrade8.Tag = "8";
            this.pbxGrade8.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade4
            // 
            this.pbxGrade4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade4.Location = new System.Drawing.Point(364, 102);
            this.pbxGrade4.Name = "pbxGrade4";
            this.pbxGrade4.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade4.TabIndex = 13;
            this.pbxGrade4.TabStop = false;
            this.pbxGrade4.Tag = "4";
            this.pbxGrade4.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade3
            // 
            this.pbxGrade3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade3.Location = new System.Drawing.Point(492, 38);
            this.pbxGrade3.Name = "pbxGrade3";
            this.pbxGrade3.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade3.TabIndex = 14;
            this.pbxGrade3.TabStop = false;
            this.pbxGrade3.Tag = "3";
            this.pbxGrade3.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade5
            // 
            this.pbxGrade5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade5.Location = new System.Drawing.Point(428, 102);
            this.pbxGrade5.Name = "pbxGrade5";
            this.pbxGrade5.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade5.TabIndex = 15;
            this.pbxGrade5.TabStop = false;
            this.pbxGrade5.Tag = "5";
            this.pbxGrade5.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade7
            // 
            this.pbxGrade7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade7.Location = new System.Drawing.Point(364, 166);
            this.pbxGrade7.Name = "pbxGrade7";
            this.pbxGrade7.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade7.TabIndex = 16;
            this.pbxGrade7.TabStop = false;
            this.pbxGrade7.Tag = "7";
            this.pbxGrade7.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade10
            // 
            this.pbxGrade10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade10.Location = new System.Drawing.Point(428, 230);
            this.pbxGrade10.Name = "pbxGrade10";
            this.pbxGrade10.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade10.TabIndex = 17;
            this.pbxGrade10.TabStop = false;
            this.pbxGrade10.Tag = "10";
            this.pbxGrade10.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbxGrade9
            // 
            this.pbxGrade9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxGrade9.Location = new System.Drawing.Point(492, 166);
            this.pbxGrade9.Name = "pbxGrade9";
            this.pbxGrade9.Size = new System.Drawing.Size(58, 58);
            this.pbxGrade9.TabIndex = 18;
            this.pbxGrade9.TabStop = false;
            this.pbxGrade9.Tag = "9";
            this.pbxGrade9.Click += new System.EventHandler(this.pbx_Click);
            // 
            // tbxMembers
            // 
            this.tbxMembers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMembers.Location = new System.Drawing.Point(158, 12);
            this.tbxMembers.Multiline = true;
            this.tbxMembers.Name = "tbxMembers";
            this.tbxMembers.ReadOnly = true;
            this.tbxMembers.Size = new System.Drawing.Size(200, 303);
            this.tbxMembers.TabIndex = 20;
            // 
            // lblConnectedUser
            // 
            this.lblConnectedUser.AutoSize = true;
            this.lblConnectedUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConnectedUser.Location = new System.Drawing.Point(290, 330);
            this.lblConnectedUser.Name = "lblConnectedUser";
            this.lblConnectedUser.Size = new System.Drawing.Size(68, 20);
            this.lblConnectedUser.TabIndex = 21;
            this.lblConnectedUser.Text = "Label 1";
            // 
            // btnAddMember
            // 
            this.btnAddMember.Enabled = false;
            this.btnAddMember.Location = new System.Drawing.Point(783, 321);
            this.btnAddMember.Name = "btnAddMember";
            this.btnAddMember.Size = new System.Drawing.Size(122, 40);
            this.btnAddMember.TabIndex = 22;
            this.btnAddMember.Text = "Ajouter un membre";
            this.btnAddMember.UseVisualStyleBackColor = true;
            this.btnAddMember.Click += new System.EventHandler(this.btnAddMember_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 373);
            this.Controls.Add(this.btnAddMember);
            this.Controls.Add(this.lblConnectedUser);
            this.Controls.Add(this.tbxMembers);
            this.Controls.Add(this.pbxGrade9);
            this.Controls.Add(this.pbxGrade10);
            this.Controls.Add(this.pbxGrade7);
            this.Controls.Add(this.pbxGrade5);
            this.Controls.Add(this.pbxGrade3);
            this.Controls.Add(this.pbxGrade4);
            this.Controls.Add(this.pbxGrade8);
            this.Controls.Add(this.pbxGrade2);
            this.Controls.Add(this.pbxGrade6);
            this.Controls.Add(this.lblAverageGrade);
            this.Controls.Add(this.pbxGrade1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnCreateClan);
            this.Controls.Add(this.lbClan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Highfeel";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrade9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox lbClan;
        private System.Windows.Forms.Button btnCreateClan;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pbxGrade1;
        private System.Windows.Forms.Label lblAverageGrade;
        private System.Windows.Forms.PictureBox pbxGrade6;
        private System.Windows.Forms.PictureBox pbxGrade2;
        private System.Windows.Forms.PictureBox pbxGrade8;
        private System.Windows.Forms.PictureBox pbxGrade4;
        private System.Windows.Forms.PictureBox pbxGrade3;
        private System.Windows.Forms.PictureBox pbxGrade5;
        private System.Windows.Forms.PictureBox pbxGrade7;
        private System.Windows.Forms.PictureBox pbxGrade10;
        private System.Windows.Forms.PictureBox pbxGrade9;
        private System.Windows.Forms.TextBox tbxMembers;
        private System.Windows.Forms.Label lblConnectedUser;
        private System.Windows.Forms.Button btnAddMember;
    }
}

